package vista;

import conexion.BdPaqueteria;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import modelo.Camion;
import modelo.Camionero;
import modelo.Ciudad;
import modelo.ConductorCamion;
import modelo.Paquete;
import util.Validaciones;

public class Menu {

    public void iniciar() {
        // Probar la conexion antes de mostrar el menu
        try (Connection con = BdPaqueteria.getConexion()) {
            if (con == null) {
                System.out.println("No hay conexion con la base de datos. Revisa MySQL.");
                return;
            }
            System.out.println("Conexion exitosa");
        } catch (SQLException e) {
            System.out.println("Error de conexion: " + e.getMessage());
            return;
        }

        int opcion;
        do {
            System.out.println("\n===== CRUD PAQUETERIA =====");
            System.out.println("1. Camion");
            System.out.println("2. Camionero");
            System.out.println("3. Paquete");
            System.out.println("4. Camionero_camion");
            System.out.println("5. Ciudad");
            System.out.println("0. Salir");
            opcion = Validaciones.leerOpcion("Elige una opcion: ");

            switch (opcion) {
                case 1:
                    menuCamion();
                    break;
                case 2:
                    menuCamionero();
                    break;
                case 3:
                    menuPaquete();
                    break;
                case 4:
                    menuConductorCamion();
                    break;
                case 5:
                    menuCiudad();
                    break;
                case 0:
                    System.out.println("Hasta luego");
                    break;
                default:
                    System.out.println("Opcion invalida. Elige un numero del menu.");
            }
        } while (opcion != 0);
    }

    private int submenu(String titulo) {
        System.out.println("\n--- " + titulo + " ---");
        System.out.println("1. Insertar");
        System.out.println("2. Listar");
        System.out.println("3. Buscar por id");
        System.out.println("4. Actualizar");
        System.out.println("5. Eliminar");
        System.out.println("0. Volver");
        return Validaciones.leerOpcion("Elige una opcion: ");
    }

    private void menuCamion() {
        int op;
        do {
            op = submenu("CAMION");
            switch (op) {
                case 1: {
                    String modelo = Validaciones.leerTexto("Modelo: ", 50);
                    String tipo = Validaciones.leerTexto("Tipo: ", 30);
                    BigDecimal potencia = Validaciones.leerDecimalPositivo("Potencia: ");
                    String placa = Validaciones.leerTexto("No. de placa: ", 10);
                    new Camion(0, modelo, tipo, potencia, placa).insertar();
                    break;
                }
                case 2: {
                    List<Camion> lista = Camion.listar();
                    if (lista.isEmpty()) {
                        System.out.println("No hay camiones registrados.");
                    }
                    for (Camion c : lista) {
                        System.out.println(c);
                    }
                    break;
                }
                case 3: {
                    int id = Validaciones.leerEntero("Id del camion: ");
                    Camion c = Camion.buscarPorId(id);
                    System.out.println(c != null ? c : "No existe un camion con id " + id);
                    break;
                }
                case 4: {
                    int id = Validaciones.leerEntero("Id del camion a actualizar: ");
                    Camion c = Camion.buscarPorId(id);
                    if (c == null) {
                        System.out.println("No existe un camion con id " + id);
                        break;
                    }
                    c.setModelo(Validaciones.leerTexto("Nuevo modelo: ", 50));
                    c.setTipo(Validaciones.leerTexto("Nuevo tipo: ", 30));
                    c.setPotencia(Validaciones.leerDecimalPositivo("Nueva potencia: "));
                    c.setNoPlaca(Validaciones.leerTexto("Nueva placa: ", 10));
                    c.actualizar();
                    break;
                }
                case 5: {
                    int id = Validaciones.leerEntero("Id del camion a eliminar: ");
                    Camion c = Camion.buscarPorId(id);
                    if (c == null) {
                        System.out.println("No existe un camion con id " + id);
                        break;
                    }
                    if (Validaciones.confirmar("Seguro que quieres eliminar " + c.getModelo() + "?")) {
                        c.eliminar();
                    } else {
                        System.out.println("Operacion cancelada.");
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        } while (op != 0);
    }

    private void menuCamionero() {
        int op;
        do {
            op = submenu("CAMIONERO");
            switch (op) {
                case 1: {
                    String nombre = Validaciones.leerTexto("Nombre: ", 50);
                    String apellidos = Validaciones.leerTexto("Apellidos: ", 50);
                    String direccion = Validaciones.leerTexto("Direccion: ", 100);
                    BigDecimal salario = Validaciones.leerDecimalPositivo("Salario: ");
                    String poblacion = Validaciones.leerTexto("Poblacion: ", 50);
                    String dpi = Validaciones.leerDigitos("DPI (13 digitos): ", 13);
                    String telefono = Validaciones.leerDigitos("Telefono (8 digitos): ", 8);
                    new Camionero(0, nombre, apellidos, direccion, salario, poblacion, dpi, telefono).insertar();
                    break;
                }
                case 2: {
                    List<Camionero> lista = Camionero.listar();
                    if (lista.isEmpty()) {
                        System.out.println("No hay camioneros registrados.");
                    }
                    for (Camionero c : lista) {
                        System.out.println(c);
                    }
                    break;
                }
                case 3: {
                    int id = Validaciones.leerEntero("Id del camionero: ");
                    Camionero c = Camionero.buscarPorId(id);
                    if (c != null) {
                        System.out.println(c);
                    }
                    break;
                }
                case 4: {
                    int id = Validaciones.leerEntero("Id del camionero a actualizar: ");
                    if (Camionero.buscarPorId(id) == null) {
                        break;
                    }
                    String nombre = Validaciones.leerTexto("Nuevo nombre: ", 50);
                    String apellidos = Validaciones.leerTexto("Nuevos apellidos: ", 50);
                    String direccion = Validaciones.leerTexto("Nueva direccion: ", 100);
                    BigDecimal salario = Validaciones.leerDecimalPositivo("Nuevo salario: ");
                    String poblacion = Validaciones.leerTexto("Nueva poblacion: ", 50);
                    String dpi = Validaciones.leerDigitos("Nuevo DPI (13 digitos): ", 13);
                    String telefono = Validaciones.leerDigitos("Nuevo telefono (8 digitos): ", 8);
                    new Camionero(id, nombre, apellidos, direccion, salario, poblacion, dpi, telefono).actualizar();
                    break;
                }
                case 5: {
                    int id = Validaciones.leerEntero("Id del camionero a eliminar: ");
                    Camionero c = Camionero.buscarPorId(id);
                    if (c == null) {
                        break;
                    }
                    if (Validaciones.confirmar("Seguro que quieres eliminar al camionero con id " + id + "?")) {
                        c.eliminar();
                    } else {
                        System.out.println("Operacion cancelada.");
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        } while (op != 0);
    }

    private void menuPaquete() {
        int op;
        do {
            op = submenu("PAQUETE");
            switch (op) {
                case 1: {
                    String descripcion = Validaciones.leerTexto("Descripcion: ", 100);
                    String destinatario = Validaciones.leerTexto("Destinatario: ", 80);
                    String direccion = Validaciones.leerTexto("Direccion: ", 100);
                    BigDecimal peso = Validaciones.leerDecimalPositivo("Peso: ");

                    Camionero camionero = Camionero.buscarPorId(Validaciones.leerEntero("Id del camionero: "));
                    if (camionero == null) {
                        System.out.println("El camionero debe existir antes de guardar el paquete.");
                        break;
                    }
                    Ciudad ciudad = Ciudad.buscarPorId(Validaciones.leerEntero("Id de la ciudad: "));
                    if (ciudad == null) {
                        System.out.println("La ciudad debe existir antes de guardar el paquete.");
                        break;
                    }
                    new Paquete(0, descripcion, destinatario, direccion, peso, camionero, ciudad).insertar();
                    break;
                }
                case 2: {
                    List<Paquete> lista = new Paquete().listar();
                    if (lista.isEmpty()) {
                        System.out.println("No hay paquetes registrados.");
                    }
                    for (Paquete p : lista) {
                        System.out.println(p);
                    }
                    break;
                }
                case 3: {
                    int id = Validaciones.leerEntero("Id del paquete: ");
                    Paquete p = new Paquete().buscarPorId(id);
                    if (p != null) {
                        System.out.println(p);
                    }
                    break;
                }
                case 4: {
                    int id = Validaciones.leerEntero("Id del paquete a actualizar: ");
                    Paquete p = new Paquete().buscarPorId(id);
                    if (p == null) {
                        break;
                    }
                    p.setDescripcion(Validaciones.leerTexto("Nueva descripcion: ", 100));
                    p.setDestinatario(Validaciones.leerTexto("Nuevo destinatario: ", 80));
                    p.setDireccion(Validaciones.leerTexto("Nueva direccion: ", 100));
                    p.setPeso(Validaciones.leerDecimalPositivo("Nuevo peso: "));

                    Camionero camionero = Camionero.buscarPorId(Validaciones.leerEntero("Id del camionero: "));
                    if (camionero == null) {
                        System.out.println("El camionero debe existir. No se actualizo el paquete.");
                        break;
                    }
                    Ciudad ciudad = Ciudad.buscarPorId(Validaciones.leerEntero("Id de la ciudad: "));
                    if (ciudad == null) {
                        System.out.println("La ciudad debe existir. No se actualizo el paquete.");
                        break;
                    }
                    p.setCamionero(camionero);
                    p.setCiudad(ciudad);
                    p.actualizar();
                    break;
                }
                case 5: {
                    int id = Validaciones.leerEntero("Id del paquete a eliminar: ");
                    Paquete p = new Paquete().buscarPorId(id);
                    if (p == null) {
                        break;
                    }
                    if (Validaciones.confirmar("Seguro que quieres eliminar el paquete " + id + "?")) {
                        p.eliminar();
                    } else {
                        System.out.println("Operacion cancelada.");
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        } while (op != 0);
    }

    // ---------------- CAMIONERO_CAMION ----------------
    private void menuConductorCamion() {
        int op;
        do {
            op = submenu("CAMIONERO_CAMION");
            switch (op) {
                case 1: {
                    Camionero conductor = Camionero.buscarPorId(Validaciones.leerEntero("Id del camionero: "));
                    if (conductor == null) {
                        System.out.println("El camionero debe existir.");
                        break;
                    }
                    Camion camion = Camion.buscarPorId(Validaciones.leerEntero("Id del camion: "));
                    if (camion == null) {
                        System.out.println("El camion debe existir.");
                        break;
                    }
                    LocalDate fecha = Validaciones.leerFecha("Fecha (AAAA-MM-DD): ");
                    new ConductorCamion(0, conductor, camion, fecha).insertar();
                    break;
                }
                case 2: {
                    List<ConductorCamion> lista = ConductorCamion.listar();
                    if (lista.isEmpty()) {
                        System.out.println("No hay asignaciones registradas.");
                    }
                    for (ConductorCamion cc : lista) {
                        System.out.println(cc);
                    }
                    break;
                }
                case 3: {
                    int id = Validaciones.leerEntero("Id de la asignacion: ");
                    ConductorCamion cc = ConductorCamion.buscarPorId(id);
                    if (cc != null) {
                        System.out.println(cc);
                    }
                    break;
                }
                case 4: {
                    int id = Validaciones.leerEntero("Id de la asignacion a actualizar: ");
                    ConductorCamion cc = ConductorCamion.buscarPorId(id);
                    if (cc == null) {
                        break;
                    }
                    Camionero conductor = Camionero.buscarPorId(Validaciones.leerEntero("Id del camionero: "));
                    if (conductor == null) {
                        System.out.println("El camionero debe existir. No se actualizo.");
                        break;
                    }
                    Camion camion = Camion.buscarPorId(Validaciones.leerEntero("Id del camion: "));
                    if (camion == null) {
                        System.out.println("El camion debe existir. No se actualizo.");
                        break;
                    }
                    cc.setConductor(conductor);
                    cc.setCamion(camion);
                    cc.setFecha(Validaciones.leerFecha("Nueva fecha (AAAA-MM-DD): "));
                    cc.actualizar();
                    break;
                }
                case 5: {
                    int id = Validaciones.leerEntero("Id de la asignacion a eliminar: ");
                    ConductorCamion cc = ConductorCamion.buscarPorId(id);
                    if (cc == null) {
                        break;
                    }
                    if (Validaciones.confirmar("Seguro que quieres eliminar la asignacion " + id + "?")) {
                        cc.eliminar();
                    } else {
                        System.out.println("Operacion cancelada.");
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        } while (op != 0);
    }

    // ---------------- CIUDAD ----------------
    private void menuCiudad() {
        int op;
        do {
            op = submenu("CIUDAD");
            switch (op) {
                case 1: {
                    String nombre = Validaciones.leerTexto("Nombre de la ciudad: ", 50);
                    new Ciudad(0, nombre).insertar();
                    break;
                }
                case 2: {
                    List<Ciudad> lista = Ciudad.listar();
                    if (lista.isEmpty()) {
                        System.out.println("No hay ciudades registradas.");
                    }
                    for (Ciudad c : lista) {
                        System.out.println(c);
                    }
                    break;
                }
                case 3: {
                    int id = Validaciones.leerEntero("Id de la ciudad: ");
                    Ciudad c = Ciudad.buscarPorId(id);
                    System.out.println(c != null ? c : "No existe una ciudad con id " + id);
                    break;
                }
                case 4: {
                    int id = Validaciones.leerEntero("Id de la ciudad a actualizar: ");
                    if (Ciudad.buscarPorId(id) == null) {
                        System.out.println("No existe una ciudad con id " + id);
                        break;
                    }
                    String nombre = Validaciones.leerTexto("Nuevo nombre: ", 50);
                    new Ciudad(id, nombre).actualizar();
                    break;
                }
                case 5: {
                    int id = Validaciones.leerEntero("Id de la ciudad a eliminar: ");
                    Ciudad c = Ciudad.buscarPorId(id);
                    if (c == null) {
                        System.out.println("No existe una ciudad con id " + id);
                        break;
                    }
                    if (Validaciones.confirmar("Seguro que quieres eliminar la ciudad con id " + id + "?")) {
                        c.eliminar();
                    } else {
                        System.out.println("Operacion cancelada.");
                    }
                    break;
                }
                case 0:
                    break;
                default:
                    System.out.println("Opcion invalida.");
            }
        } while (op != 0);
    }
}