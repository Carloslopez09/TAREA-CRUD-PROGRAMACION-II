/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
 
import conexion.BdPaqueteria;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
/**
 *
 * @author carlo
 */
public class Paquete {
 
    private int idPaquete;
    private String descripcion;
    private String destinatario;
    private String direccion;
    private BigDecimal peso;
    private Camionero camionero;
    private Ciudad ciudad;
 
    public Paquete() {
    }
 
    public Paquete(int idPaquete, String descripcion, String destinatario, String direccion, BigDecimal peso, Camionero camionero, Ciudad ciudad) {
        this.idPaquete = idPaquete;
        this.descripcion = descripcion;
        this.destinatario = destinatario;
        this.direccion = direccion;
        this.peso = peso;
        this.camionero = camionero;
        this.ciudad = ciudad;
    }
 
    public int getIdPaquete() {
        return idPaquete;
    }
 
    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }
 
    public String getDescripcion() {
        return descripcion;
    }
 
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
 
    public String getDestinatario() {
        return destinatario;
    }
 
    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }
 
    public String getDireccion() {
        return direccion;
    }
 
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
 
    public BigDecimal getPeso() {
        return peso;
    }
 
    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }
 
    public Camionero getCamionero() {
        return camionero;
    }
 
    public void setCamionero(Camionero camionero) {
        this.camionero = camionero;
    }
 
    public Ciudad getCiudad() {
        return ciudad;
    }
 
    public void setCiudad(Ciudad ciudad) {
        this.ciudad = ciudad;
    }
 
    @Override
    public String toString() {
        return "Paquete{" + "idPaquete=" + idPaquete + ", descripcion=" + descripcion + ", destinatario=" + destinatario + ", direccion=" + direccion + ", peso=" + peso + ", camionero=" + camionero + ", ciudad=" + ciudad + '}';
    }
 
    public void insertar() {
        if (this.camionero == null || this.ciudad == null) {
            System.out.println("Error: el paquete necesita un camionero y una ciudad válidos");
            return;
        }
 
        String sql = "INSERT INTO paquete (descripcion, destinatario, peso, direccion, idCamionero, idCiudad) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setString(1, this.descripcion);
            ps.setString(2, this.destinatario);
            ps.setBigDecimal(3, this.peso);
            ps.setString(4, this.direccion);
            ps.setInt(5, this.camionero.getidCamionero());
            ps.setInt(6, this.ciudad.getidCiudad());
 
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Paquete guardado");
            }
 
        } catch (SQLException e) {
            System.out.println("Error al guardar el paquete: " + e.getMessage());
        }
    }
 
    public List<Paquete> listar() {
        List<Paquete> lista = new ArrayList<>();
        String sql = "SELECT idPaquete, descripcion, destinatario, peso, direccion, idCamionero, idCiudad FROM paquete";
 
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
 
            while (rs.next()) {
                Paquete p = new Paquete();
                p.setIdPaquete(rs.getInt("idPaquete"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setDestinatario(rs.getString("destinatario"));
                p.setPeso(rs.getBigDecimal("peso"));
                p.setDireccion(rs.getString("direccion"));
                p.setCamionero(Camionero.buscarPorId(rs.getInt("idCamionero")));
                p.setCiudad(Ciudad.buscarPorId(rs.getInt("idCiudad")));
                lista.add(p);
            }
 
        } catch (SQLException e) {
            System.out.println("Error al listar paquetes: " + e.getMessage());
        }
        return lista;
    }
 
    public Paquete buscarPorId(int id) {
        String sql = "SELECT idPaquete, descripcion, destinatario, peso, direccion, idCamionero, idCiudad FROM paquete WHERE idPaquete = ?";
 
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, id);
 
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Paquete p = new Paquete();
                    p.setIdPaquete(rs.getInt("idPaquete"));
                    p.setDescripcion(rs.getString("descripcion"));
                    p.setDestinatario(rs.getString("destinatario"));
                    p.setPeso(rs.getBigDecimal("peso"));
                    p.setDireccion(rs.getString("direccion"));
                    p.setCamionero(Camionero.buscarPorId(rs.getInt("idCamionero")));
                    p.setCiudad(Ciudad.buscarPorId(rs.getInt("idCiudad")));
                    return p;
                }
            }
 
        } catch (SQLException e) {
            System.out.println("Error al buscar el paquete: " + e.getMessage());
        }
        System.out.println("No existe un paquete con id " + id);
        return null;
    }
 
    public void actualizar() {
        if (this.camionero == null || this.ciudad == null) {
            System.out.println("Error: el paquete necesita un camionero y una ciudad válidos");
            return;
        }
 
        String sql = "UPDATE paquete SET descripcion = ?, destinatario = ?, peso = ?, direccion = ?, idCamionero = ?, idCiudad = ? WHERE idPaquete = ?";
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setString(1, this.descripcion);
            ps.setString(2, this.destinatario);
            ps.setBigDecimal(3, this.peso);
            ps.setString(4, this.direccion);
            ps.setInt(5, this.camionero.getidCamionero());
            ps.setInt(6, this.ciudad.getidCiudad());
            ps.setInt(7, this.idPaquete);
 
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Paquete actualizado");
            } else {
                System.out.println("No existe un paquete con id " + this.idPaquete);
            }
 
        } catch (SQLException e) {
            System.out.println("Error al actualizar el paquete: " + e.getMessage());
        }
    }
 
    public void eliminar() {
        String sql = "DELETE FROM paquete WHERE idPaquete = ?";
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, this.idPaquete);
 
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Paquete eliminado");
            } else {
                System.out.println("No existe un paquete con id " + this.idPaquete);
            }
 
        } catch (SQLException e) {
            System.out.println("Error al eliminar el paquete: " + e.getMessage());
        }
    }
}