/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.math.BigDecimal;
import conexion.BdPaqueteria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author carlo
 */
public class Camion {
    
    private int idCamion;
    private String modelo;
    private String tipo;
    private BigDecimal potencia;
    private String noPlaca;

    public int getIdCamion() {
        return idCamion;
    }

    public void setIdCamion(int idCamion) {
        this.idCamion = idCamion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public BigDecimal getPotencia() {
        return potencia;
    }

    public void setPotencia(BigDecimal potencia) {
        this.potencia = potencia;
    }

    public String getNoPlaca() {
        return noPlaca;
    }

    public void setNoPlaca(String noPlaca) {
        this.noPlaca = noPlaca;
    }

    public Camion() {
        
    }

    public Camion(int idCamion, String modelo, String tipo, BigDecimal potencia, String noPlaca) {
        this.idCamion = idCamion;
        this.modelo = modelo;
        this.tipo = tipo;
        this.potencia = potencia;
        this.noPlaca = noPlaca;
    }

    
    @Override
    public String toString() {
        return "Camion{" + "idCamion=" + idCamion + ", modelo=" + modelo + ", tipo=" + tipo + ", potencia=" + potencia + ", noPlaca=" + noPlaca + '}';
    }
    
    public void insertar() {
    String sql = "INSERT INTO camion (modelo, tipo, potencia, noPlaca) VALUES (?, ?, ?, ?)";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, this.modelo);
        ps.setString(2, this.tipo);
        ps.setBigDecimal(3, this.potencia);
        ps.setString(4, this.noPlaca);
        ps.executeUpdate();
        System.out.println("Camion guardado");
        // aquí: ejecutar con ps.executeUpdate() y mostrar un mensaje de éxito

    } catch (SQLException e) {
        System.out.println("Error al guardar: " + e.getMessage());
        // aquí: mostrar un mensaje con e.getMessage()
        }
    }
     
     
    public static List<Camion> listar() {
    List<Camion> lista = new ArrayList<>();
    String sql = "SELECT * FROM camion";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            lista.add(new Camion(rs.getInt("idCamion"), rs.getString("modelo"), rs.getString("tipo"), rs.getBigDecimal("potencia"), rs.getString("noPlaca")));
        }

    } catch (SQLException e) {
        System.out.println("Error al listar: " + e.getMessage());
    }
    return lista;
    } 
     
    public static Camion buscarPorId(int id) {
    String sql = "SELECT * FROM camion WHERE idCamion = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new Camion(rs.getInt("idCamion"), rs.getString("modelo"),rs.getString("tipo"),rs.getBigDecimal("potencia"),rs.getString("noPlaca"));
            }
        }

        } catch (SQLException e) {
        System.out.println("Error al buscar: " + e.getMessage());
        }
        return null;
    } 
     
    public void actualizar() {
    String sql = "UPDATE camion SET modelo = ?, tipo = ?, potencia = ?, noPlaca = ? WHERE idCamion = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

              // aquí van los cinco set, con las posiciones 1, 2, 3, 4 y 5
        ps.setString(1, this.modelo);
        ps.setString(2, this.tipo);     
        ps.setBigDecimal(3, this.potencia);
        ps.setString(4, this.noPlaca);
        ps.setInt(5, this.idCamion);
        ps.executeUpdate();
        System.out.println("Camion actualizado");

    } catch (SQLException e) {
        System.out.println("Error al actualizar: " + e.getMessage());
    }
}
    
    public void eliminar() {
    String sql = "DELETE FROM camion WHERE idCamion = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, this.idCamion);
        ps.executeUpdate();
        System.out.println("Camion eliminada");

    } catch (SQLException e) {
        System.out.println("Error al eliminar: " + e.getMessage());
    }
    }
     
}
