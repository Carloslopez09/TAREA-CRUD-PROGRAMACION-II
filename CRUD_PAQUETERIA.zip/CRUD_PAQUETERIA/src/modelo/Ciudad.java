/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import conexion.BdPaqueteria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author carlo
 */
public class Ciudad {
    private int idCiudad;
    private String nombre;

    public Ciudad(int idCiudad, String nombre) {
        this.idCiudad = idCiudad;
        this.nombre = nombre;
    }

    public Ciudad() {
    }

    public int getIdCiudad() {
        return idCiudad;
    }   

    public void setIdCiudad(int idCiudad) {
        this.idCiudad = idCiudad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Ciudad{" + "idCiudad=" + idCiudad + ", nombre=" + nombre + '}';
    }
    
    public void insertar() {
    String sql = "INSERT INTO ciudad (nombre) VALUES (?)";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, this.nombre);
        ps.executeUpdate();
        System.out.println("Ciudad guardada");
        // aquí: ejecutar con ps.executeUpdate() y mostrar un mensaje de éxito

    } catch (SQLException e) {
        System.out.println("Error al guardar: " + e.getMessage());
        // aquí: mostrar un mensaje con e.getMessage()
        }
    }
    
    public static List<Ciudad> listar() {
    List<Ciudad> lista = new ArrayList<>();
    String sql = "SELECT * FROM ciudad";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            
            lista.add(new Ciudad(rs.getInt("idCiudad"), rs.getString("nombre")));
            }

        } catch (SQLException e) {
        System.out.println("Error al listar: " + e.getMessage());
        }
    return lista;
    }
    
    public static Ciudad buscarPorId(int id) {
    String sql = "SELECT idCiudad, nombre FROM ciudad WHERE idCiudad = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                Ciudad ci = new Ciudad();
                ci.setIdCiudad(rs.getInt("idCiudad"));
                ci.setNombre(rs.getString("nombre"));
                return ci;
            }
        }

    } catch (SQLException e) {
        System.out.println("Error al buscar la ciudad: " + e.getMessage());
    }
    System.out.println("No existe una ciudad con id " + id);
    return null;
}
    
    
    
    public void actualizar() {
    String sql = "UPDATE ciudad SET nombre = ? WHERE idCiudad = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, this.nombre);
        ps.setInt(2, this.idCiudad);
        ps.executeUpdate();
        System.out.println("Ciudad actualizada");

    } catch (SQLException e) {
        System.out.println("Error al actualizar: " + e.getMessage());
        }
    }
    
    public void eliminar() {
    String sql = "DELETE FROM ciudad WHERE idCiudad = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, this.idCiudad);
        ps.executeUpdate();
        System.out.println("Ciudad eliminada");

    } catch (SQLException e) {
        System.out.println("Error al eliminar: " + e.getMessage());
    }
    }

    int getidCiudad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
