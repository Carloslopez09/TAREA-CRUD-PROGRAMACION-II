/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.math.BigDecimal;
import conexion.BdPaqueteria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author carlo
 */
public class Camionero {
    private int idCamionero;
    private String nombre;
    private String apellidos;
    private String direccion;
    private BigDecimal salario;
    private String poblacion;
    private String dpi;
    private String telefono;

    public int getidCamionero() {
        return idCamionero;
    }

    public void setidCamionero(int idCamionero) {
        this.idCamionero = idCamionero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public String getDpi() {
        return dpi;
    }

    public void setDpi(String dpi) {
        this.dpi = dpi;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Camionero(int idCamionero, String nombre, String apellidos, String direccion, BigDecimal salario, String poblacion, String dpi, String telefono) {
        this.idCamionero = idCamionero;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.salario = salario;
        this.poblacion = poblacion;
        this.dpi = dpi;
        this.telefono = telefono;
    }
    

    @Override
    public String toString() {
        return "Camionero{" + "idCamionero=" + idCamionero + ", nombre=" + nombre + ", apellidos=" + apellidos + ", direccion=" + direccion + ", salario=" + salario + ", poblacion=" + poblacion + ", dpi=" + dpi + ", telefono=" + telefono + '}';
    }

    public Camionero() {
    }
    
    public void insertar() {
    String sql = "INSERT INTO camionero (nombre, apellidos, direccion, salario, poblacion, dpi, telefono) VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, this.nombre);
        ps.setString(2, this.apellidos);
        ps.setString(3, this.direccion);
        ps.setBigDecimal(4, this.salario);
        ps.setString(5, this.poblacion);
        ps.setString(6, this.dpi);
        ps.setString(7, this.telefono);
        ps.executeUpdate();
        System.out.println("Camionero guardado");
        // aquí: ejecutar con ps.executeUpdate() y mostrar un mensaje de éxito

    } catch (SQLException e) {
        System.out.println("Error al guardar: " + e.getMessage());
        // aquí: mostrar un mensaje con e.getMessage()
        }
    }
    
    public static List<Camionero> listar() {
    List<Camionero> lista = new ArrayList<>();
    String sql = "SELECT * FROM camionero";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            lista.add(new Camionero(rs.getInt("idCamionero"), rs.getString("nombre"), rs.getString("apellidos"),
                    rs.getString("direccion"), rs.getBigDecimal("salario"), rs.getString("poblacion"), rs.getString("dpi"), rs.getString("telefono")));
        }

    } catch (SQLException e) {
        System.out.println("Error al listar: " + e.getMessage());
    }
    return lista;
    } 
    
    public static Camionero buscarPorId(int id) {
    String sql = "SELECT idCamionero, nombre, apellidos, direccion, salario, poblacion, dpi, telefono FROM camionero WHERE idCamionero = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                Camionero c = new Camionero();
                c.setidCamionero(rs.getInt("idCamionero"));
                c.setNombre(rs.getString("nombre"));
                c.setApellidos(rs.getString("apellidos"));
                c.setDireccion(rs.getString("direccion"));
                c.setSalario(rs.getBigDecimal("salario"));
                c.setPoblacion(rs.getString("poblacion"));
                c.setDpi(rs.getString("dpi"));
                c.setTelefono(rs.getString("telefono"));
                return c;
            }
        }

    } catch (SQLException e) {
        System.out.println("Error al buscar el camionero: " + e.getMessage());
    }
    System.out.println("No existe un camionero con id " + id);
    return null;
}
    
    public void actualizar() {
    String sql = "UPDATE camionero SET nombre = ?, apellidos = ?, direccion = ?, salario = ?, poblacion = ?, dpi = ?, telefono = ? WHERE idCamionero = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

              // aquí van los cinco set, con las posiciones 1, 2, 3, 4 y 5
        ps.setString(1, this.nombre);
        ps.setString(2, this.apellidos);     
        ps.setString(3, this.direccion);
        ps.setBigDecimal(4, this.salario);
        ps.setString(5, this.poblacion);
        ps.setString(6, this.dpi);
        ps.setString(7, this.telefono);
        ps.setInt(8, this.idCamionero);
        ps.executeUpdate();
        System.out.println("Camion actualizado");

    } catch (SQLException e) {
        System.out.println("Error al actualizar: " + e.getMessage());
    }
}
    
    public void eliminar() {
    String sql = "DELETE FROM camion WHERE idCamionero = ?";
    try (Connection con = BdPaqueteria.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, this.idCamionero);
        ps.executeUpdate();
        System.out.println("Camionero eliminada");

    } catch (SQLException e) {
        System.out.println("Error al eliminar: " + e.getMessage());
    }
    }
}
