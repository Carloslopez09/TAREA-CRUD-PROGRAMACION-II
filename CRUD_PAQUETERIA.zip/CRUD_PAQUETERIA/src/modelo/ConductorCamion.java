/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
 
import conexion.BdPaqueteria;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
 
/**
 * Clase del diagrama: ConductorCamion
 * Tabla en la base de datos: camionero_camion
 */
public class ConductorCamion {
 
    private int idConductorCamion;
    private Camionero conductor;   // objeto, no id
    private Camion camion;         // objeto, no id
    private LocalDate fecha;
 
    public ConductorCamion() {
    }
 
    public ConductorCamion(int idConductorCamion, Camionero conductor, Camion camion, LocalDate fecha) {
        this.idConductorCamion = idConductorCamion;
        this.conductor = conductor;
        this.camion = camion;
        this.fecha = fecha;
    }
 
    public int getIdConductorCamion() {
        return idConductorCamion;
    }
 
    public void setIdConductorCamion(int idConductorCamion) {
        this.idConductorCamion = idConductorCamion;
    }
 
    public Camionero getConductor() {
        return conductor;
    }
 
    public void setConductor(Camionero conductor) {
        this.conductor = conductor;
    }
 
    public Camion getCamion() {
        return camion;
    }
 
    public void setCamion(Camion camion) {
        this.camion = camion;
    }
 
    public LocalDate getFecha() {
        return fecha;
    }
 
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
 
    @Override
    public String toString() {
        return "ConductorCamion{" + "idConductorCamion=" + idConductorCamion
                + ", conductor=" + conductor
                + ", camion=" + camion
                + ", fecha=" + fecha + '}';
    }
 
    // ---------------- CRUD ----------------
 
    public void insertar() {
        if (this.conductor == null || this.camion == null || this.fecha == null) {
            System.out.println("Error: se necesita un camionero, un camion y una fecha validos");
            return;
        }
 
        String sql = "INSERT INTO camionero_camion (idCamionero, idCamion, fecha) VALUES (?, ?, ?)";
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, this.conductor.getidCamionero());
            ps.setInt(2, this.camion.getIdCamion());
            ps.setDate(3, Date.valueOf(this.fecha));
 
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Asignacion guardada");
            }
 
        } catch (SQLException e) {
            System.out.println("Error al guardar la asignacion: " + e.getMessage());
        }
    }
 
    public static List<ConductorCamion> listar() {
        List<ConductorCamion> lista = new ArrayList<>();
        String sql = "SELECT idConductorCamion, idCamionero, idCamion, fecha FROM camionero_camion";
 
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
 
            while (rs.next()) {
                ConductorCamion cc = new ConductorCamion();
                cc.setIdConductorCamion(rs.getInt("idConductorCamion"));
                cc.setConductor(Camionero.buscarPorId(rs.getInt("idCamionero")));
                cc.setCamion(Camion.buscarPorId(rs.getInt("idCamion")));
                cc.setFecha(rs.getDate("fecha").toLocalDate());
                lista.add(cc);
            }
 
        } catch (SQLException e) {
            System.out.println("Error al listar asignaciones: " + e.getMessage());
        }
        return lista;
    }
 
    public static ConductorCamion buscarPorId(int id) {
        String sql = "SELECT idConductorCamion, idCamionero, idCamion, fecha FROM camionero_camion WHERE idConductorCamion = ?";
 
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, id);
 
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ConductorCamion cc = new ConductorCamion();
                    cc.setIdConductorCamion(rs.getInt("idConductorCamion"));
                    cc.setConductor(Camionero.buscarPorId(rs.getInt("idCamionero")));
                    cc.setCamion(Camion.buscarPorId(rs.getInt("idCamion")));
                    cc.setFecha(rs.getDate("fecha").toLocalDate());
                    return cc;
                }
            }
 
        } catch (SQLException e) {
            System.out.println("Error al buscar la asignacion: " + e.getMessage());
        }
        System.out.println("No existe una asignacion con id " + id);
        return null;
    }
 
    public void actualizar() {
        if (this.conductor == null || this.camion == null || this.fecha == null) {
            System.out.println("Error: se necesita un camionero, un camion y una fecha validos");
            return;
        }
 
        String sql = "UPDATE camionero_camion SET idCamionero = ?, idCamion = ?, fecha = ? WHERE idConductorCamion = ?";
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, this.conductor.getidCamionero());
            ps.setInt(2, this.camion.getIdCamion());
            ps.setDate(3, Date.valueOf(this.fecha));
            ps.setInt(4, this.idConductorCamion);
 
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Asignacion actualizada");
            } else {
                System.out.println("No existe una asignacion con id " + this.idConductorCamion);
            }
 
        } catch (SQLException e) {
            System.out.println("Error al actualizar la asignacion: " + e.getMessage());
        }
    }
 
    public void eliminar() {
        String sql = "DELETE FROM camionero_camion WHERE idConductorCamion = ?";
        try (Connection con = BdPaqueteria.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, this.idConductorCamion);
 
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Asignacion eliminada");
            } else {
                System.out.println("No existe una asignacion con id " + this.idConductorCamion);
            }
 
        } catch (SQLException e) {
            System.out.println("Error al eliminar la asignacion: " + e.getMessage());
        }
    }
}