/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author carlo
 */
public class BdPaqueteria {
    
    private static final String  URL = "jdbc:mysql://localhost:3306/db_paqueteria";
    private static final String USUARIO = "root";
    private static final String CONTRA = "tu_contraseña";
    
    
    public static Connection getConexion(){
        try{
            return DriverManager.getConnection(URL, USUARIO, CONTRA);
            
        } catch (SQLException e){
            
            System.out.println("No se pudo conectar: " + e.getMessage());
        }
        return null;
        
   }

}
