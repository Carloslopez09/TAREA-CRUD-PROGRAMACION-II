/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package crud_paqueteria;

import conexion.BdPaqueteria;
import java.sql.Connection;
import modelo.Ciudad;
import modelo.Camion;
import java.math.BigDecimal;
import java.time.LocalDate;
import modelo.Camionero;
import modelo.Paquete;
import modelo.ConductorCamion;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import vista.Menu;
/**
 *
 * @author carlo
 */
public class CRUD_PAQUETERIA {


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Menu().iniciar();
        
        Ciudad c = new Ciudad(1, "Huehuetenango");
        System.out.println(c);
        
        Camion cam = new Camion(1, "Hino 500", "Carga pesada", new BigDecimal("350.50"), "C123ABC");
        System.out.println(cam);
        
        Camionero nero = new Camionero(1, "Carlos", "Lopez", "Zona 1", new BigDecimal("3500.00"), "Huehuetenango", "1234567890123", "55512345");
        System.out.println(nero);
            
        Paquete paq = new Paquete(1, "Cajas de ropa", "Maria Perez", "Zona 3", new BigDecimal("25.50"), nero, c);
        System.out.println(paq);
        
        ConductorCamion cc = new ConductorCamion(1, nero, cam, LocalDate.of(2026, 10, 22));
        System.out.println(cc);
        
        //ciudad
        Ciudad nueva = new Ciudad(0, "Quetzaltenango");
        nueva.insertar();
        
        /*List<Ciudad> ciudades = Ciudad.listar();
        for (Ciudad ci : ciudades) {
            System.out.println(ci);
        }*/
        
        Ciudad buscada = Ciudad.buscarPorId(2);
        if (buscada != null) {
            System.out.println(buscada);
        } else {
            System.out.println("No existe esa ciudad");
        }
        
        Ciudad cambio = new Ciudad(2, "Xela");
        cambio.actualizar();
        
        Ciudad borrar = new Ciudad(5, "");
            borrar.eliminar();
            
        //camion    
        Camion nuevo = new Camion(0, "Volvo FH", "Carga pesada", new BigDecimal("420.00"), "C456DEF");
        nuevo.insertar();    
        
        /*List<Camion> camiones = Camion.listar();
        for (Camion ca : camiones) {
            System.out.println(ca);
        } }*/
        
        Camion buscado = Camion.buscarPorId(1);
        if (buscado != null) {
            System.out.println(buscado);
        } else {
            System.out.println("No existe ese camion");
        }
        
        Camion cambioCamion = new Camion(1, "Hino 700", "Carga pesada", new BigDecimal("400.00"), "C123ABC");
        cambioCamion.actualizar();
        
        Camion borrarCamion = new Camion(2, "", "", null, "");
        borrarCamion.eliminar();
        
        
        //camionero
        Camionero nuevoCamionero = new Camionero(0, "Pedro", "Gomez", "Zona 5", new BigDecimal("3200.00"), "Huehuetenango", "9876543210123", "55598765");
        nuevoCamionero.insertar();
        
        /*List<Camionero> camioneros = Camionero.listar();
        for (Camionero ce : camioneros) {
            System.out.println(ce);
        }*/
        
        Camionero buscadoCamionero = Camionero.buscarPorId(1);
        if (buscadoCamionero != null) {
            System.out.println(buscadoCamionero);
        } else {
            System.out.println("No existe ese camionero");
        }
        
        Camionero camioneroCambio = new Camionero(0, "Raul", "Miranda", "zona 2" ,new BigDecimal("400.00"), "San Marcos", "4568521456354", "54245445");
        camioneroCambio.actualizar();
        
        Camionero borrarCamionero = new Camionero(1, "", "", "",null, "","", "");
        borrarCamionero.eliminar();

        //cAMIONEROCAMION
        Camionero conductorCC = Camionero.buscarPorId(2);
        Camion camionCC = Camion.buscarPorId(1);
        
        if (conductorCC != null && camionCC != null) {
            ConductorCamion nuevaAsignacion = new ConductorCamion(0, conductorCC, camionCC, LocalDate.of(2026, 10, 22));
            nuevaAsignacion.insertar();
        }
        
        List<ConductorCamion> asignaciones = ConductorCamion.listar();
            for (ConductorCamion a : asignaciones) {
                System.out.println(a);
            }if (!asignaciones.isEmpty()) {
                int idPruebaCC = asignaciones.get(asignaciones.size() - 1).getIdConductorCamion();  
            
        // BUSCAR POR ID
                ConductorCamion encontradaCC = ConductorCamion.buscarPorId(idPruebaCC);
                System.out.println(encontradaCC);
 
                if (encontradaCC != null) {
                    // ACTUALIZAR
                    encontradaCC.setFecha(LocalDate.of(2026, 10, 23));
                    encontradaCC.actualizar();
 
                    // ELIMINAR (comenta esta linea si quieres capturar el dato en Workbench antes de borrarlo)
                    encontradaCC.eliminar();
                }
        } else {
            System.out.println("El camionero o el camion no existe");
        } 
        
        
        
        
        // Paquete
        Camionero camioneroPaquete = Camionero.buscarPorId(2);
        Ciudad ciudadPaquete = Ciudad.buscarPorId(1);

        if (camioneroPaquete != null && ciudadPaquete != null) {
            Paquete p = new Paquete(0, "Cajas", "Juan Perez", "Zona 1", new BigDecimal("12.5"), camioneroPaquete, ciudadPaquete);
            p.insertar();

            List<Paquete> paquetes = new Paquete().listar();
            for (Paquete pq : paquetes) {
                System.out.println(pq);
            }

            if (!paquetes.isEmpty()) {
                int idPrueba = paquetes.get(paquetes.size() - 1).getIdPaquete();

                Paquete encontrado = new Paquete().buscarPorId(idPrueba);
                System.out.println(encontrado);

                if (encontrado != null) {
                    encontrado.setDescripcion("Cajas actualizadas");
                    encontrado.setPeso(new BigDecimal("20.00"));
                    encontrado.actualizar();

                    // Comenta esta línea si quieres una captura de Workbench con el paquete aún existente
                    encontrado.eliminar();
                }
            }
        } else {
            System.out.println("El camionero o la ciudad no existe");
        }

        
        
        Connection con = BdPaqueteria.getConexion();
        
        if(con != null){
            System.out.println("Conexion exitoso");
        }
        else{
            System.out.println("No hay conexión");
        }
        // TODO code application logic here
    }
       
}
