package util;
 
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
 
public class Validaciones {
 
    private static final Scanner sc = new Scanner(System.in);
 
    // Texto obligatorio: no vacio, sin solo espacios y con longitud maxima
    public static String leerTexto(String mensaje, int max) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            if (texto.isEmpty()) {
                System.out.println("Error: este campo no puede estar vacio. Escribe un valor.");
            } else if (texto.length() > max) {
                System.out.println("Error: maximo " + max + " caracteres. Escribe un texto mas corto.");
            } else {
                return texto;
            }
        }
    }
 
    // Numero entero mayor que 0 (para ids)
    public static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            try {
                int numero = Integer.parseInt(texto);
                if (numero > 0) {
                    return numero;
                }
                System.out.println("Error: el numero debe ser mayor que 0.");
            } catch (NumberFormatException e) {
                System.out.println("Error: escribe un numero entero valido.");
            }
        }
    }
 
    // Opcion de menu (permite 0)
    public static int leerOpcion(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException e) {
                System.out.println("Error: escribe solo un numero del menu.");
            }
        }
    }
 
    // Decimal mayor que 0 (salario, peso, potencia)
    public static BigDecimal leerDecimalPositivo(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            try {
                BigDecimal numero = new BigDecimal(texto);
                if (numero.compareTo(BigDecimal.ZERO) > 0) {
                    return numero;
                }
                System.out.println("Error: el valor debe ser mayor que 0.");
            } catch (NumberFormatException e) {
                System.out.println("Error: escribe un numero valido, por ejemplo 350.50");
            }
        }
    }
 
    // Exactamente N digitos numericos (DPI = 13, telefono = 8)
    public static String leerDigitos(String mensaje, int cantidad) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            if (texto.matches("\\d{" + cantidad + "}")) {
                return texto;
            }
            System.out.println("Error: debe tener exactamente " + cantidad + " digitos numericos.");
        }
    }
 
    // Fecha en formato AAAA-MM-DD
    public static LocalDate leerFecha(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            try {
                return LocalDate.parse(texto);
            } catch (DateTimeParseException e) {
                System.out.println("Error: formato invalido. Usa AAAA-MM-DD, por ejemplo 2026-10-22.");
            }
        }
    }
 
    // Confirmacion s/n
    public static boolean confirmar(String mensaje) {
        while (true) {
            System.out.print(mensaje + " (s/n): ");
            String texto = sc.nextLine().trim().toLowerCase();
            if (texto.equals("s")) {
                return true;
            }
            if (texto.equals("n")) {
                return false;
            }
            System.out.println("Error: responde s o n.");
        }
    }
}